"use client"

import { useState } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Badge } from "@/components/ui/badge"
import { Wifi, Zap, Clock, ArrowLeft } from "lucide-react"
import Link from "next/link"

const networks = [
  {
    name: "MTN",
    color: "bg-yellow-500",
    plans: [
      { size: "1GB", duration: "30 days", price: 300, originalPrice: 350 },
      { size: "2GB", duration: "30 days", price: 500, originalPrice: 600 },
      { size: "5GB", duration: "30 days", price: 1200, originalPrice: 1500 },
      { size: "10GB", duration: "30 days", price: 2000, originalPrice: 2500 },
    ],
  },
  {
    name: "Airtel",
    color: "bg-red-500",
    plans: [
      { size: "1GB", duration: "30 days", price: 280, originalPrice: 330 },
      { size: "2GB", duration: "30 days", price: 480, originalPrice: 580 },
      { size: "5GB", duration: "30 days", price: 1150, originalPrice: 1400 },
      { size: "10GB", duration: "30 days", price: 1900, originalPrice: 2300 },
    ],
  },
  {
    name: "Glo",
    color: "bg-green-500",
    plans: [
      { size: "1GB", duration: "30 days", price: 250, originalPrice: 300 },
      { size: "2GB", duration: "30 days", price: 450, originalPrice: 550 },
      { size: "5GB", duration: "30 days", price: 1100, originalPrice: 1350 },
      { size: "10GB", duration: "30 days", price: 1800, originalPrice: 2200 },
    ],
  },
  {
    name: "9Mobile",
    color: "bg-purple-500",
    plans: [
      { size: "1GB", duration: "30 days", price: 320, originalPrice: 380 },
      { size: "2GB", duration: "30 days", price: 520, originalPrice: 620 },
      { size: "5GB", duration: "30 days", price: 1250, originalPrice: 1550 },
      { size: "10GB", duration: "30 days", price: 2100, originalPrice: 2600 },
    ],
  },
]

export default function DataPage() {
  const [selectedNetwork, setSelectedNetwork] = useState("MTN")
  const [selectedPlan, setSelectedPlan] = useState<any>(null)
  const [phoneNumber, setPhoneNumber] = useState("")

  const currentNetwork = networks.find((n) => n.name === selectedNetwork)

  const handlePurchase = () => {
    console.log("Purchase:", { selectedNetwork, selectedPlan, phoneNumber })
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-purple-50 to-indigo-100 py-12 px-4 sm:px-6 lg:px-8">
      <div className="max-w-6xl mx-auto">
        {/* Navigation */}
        <div className="mb-6">
          <Link href="/" className="inline-flex items-center text-purple-600 hover:text-purple-700">
            <ArrowLeft className="w-4 h-4 mr-2" />
            Back to Home
          </Link>
        </div>

        <div className="text-center mb-8">
          <div className="w-16 h-16 bg-purple-500 rounded-full flex items-center justify-center mx-auto mb-4">
            <Wifi className="w-8 h-8 text-white" />
          </div>
          <h1 className="text-3xl font-bold text-gray-900 mb-2">Buy Data Bundles</h1>
          <p className="text-gray-600">Affordable data plans for all networks</p>
        </div>

        <div className="grid lg:grid-cols-3 gap-8">
          <div className="lg:col-span-2">
            {/* Network Selection */}
            <Card className="mb-6">
              <CardHeader>
                <CardTitle>Select Network</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
                  {networks.map((network) => (
                    <Button
                      key={network.name}
                      variant={selectedNetwork === network.name ? "default" : "outline"}
                      className={`h-16 ${selectedNetwork === network.name ? network.color : ""}`}
                      onClick={() => {
                        setSelectedNetwork(network.name)
                        setSelectedPlan(null)
                      }}
                    >
                      <div className="text-center">
                        <div className="font-semibold">{network.name}</div>
                        <div className="text-xs opacity-75">Data Plans</div>
                      </div>
                    </Button>
                  ))}
                </div>
              </CardContent>
            </Card>

            {/* Data Plans */}
            <Card>
              <CardHeader>
                <CardTitle>{selectedNetwork} Data Plans</CardTitle>
                <CardDescription>Choose your preferred data bundle</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="grid md:grid-cols-2 gap-4">
                  {currentNetwork?.plans.map((plan, index) => (
                    <Card
                      key={index}
                      className={`cursor-pointer transition-all ${
                        selectedPlan?.size === plan.size ? "ring-2 ring-purple-500 bg-purple-50" : "hover:shadow-md"
                      }`}
                      onClick={() => setSelectedPlan(plan)}
                    >
                      <CardContent className="p-4">
                        <div className="flex justify-between items-start mb-2">
                          <div>
                            <h3 className="text-lg font-semibold">{plan.size}</h3>
                            <div className="flex items-center text-sm text-gray-600">
                              <Clock className="w-4 h-4 mr-1" />
                              {plan.duration}
                            </div>
                          </div>
                          <div className="text-right">
                            <div className="text-lg font-bold text-green-600">₦{plan.price}</div>
                            <div className="text-sm text-gray-500 line-through">₦{plan.originalPrice}</div>
                          </div>
                        </div>
                        <Badge variant="secondary" className="text-xs">
                          Save ₦{plan.originalPrice - plan.price}
                        </Badge>
                      </CardContent>
                    </Card>
                  ))}
                </div>
              </CardContent>
            </Card>
          </div>

          <div className="space-y-6">
            {/* Phone Number Input */}
            <Card>
              <CardHeader>
                <CardTitle>Phone Number</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-2">
                  <Label htmlFor="phone">Enter phone number</Label>
                  <Input
                    id="phone"
                    type="tel"
                    placeholder="08012345678"
                    value={phoneNumber}
                    onChange={(e) => setPhoneNumber(e.target.value)}
                  />
                </div>
              </CardContent>
            </Card>

            {/* Order Summary */}
            <Card>
              <CardHeader>
                <CardTitle>Order Summary</CardTitle>
              </CardHeader>
              <CardContent className="space-y-3">
                <div className="flex justify-between">
                  <span className="text-gray-600">Network:</span>
                  <span className="font-medium">{selectedNetwork}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-gray-600">Data Plan:</span>
                  <span className="font-medium">{selectedPlan?.size || "Not selected"}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-gray-600">Duration:</span>
                  <span className="font-medium">{selectedPlan?.duration || "N/A"}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-gray-600">Phone:</span>
                  <span className="font-medium">{phoneNumber || "Not entered"}</span>
                </div>
                <hr />
                <div className="flex justify-between text-lg font-semibold">
                  <span>Total:</span>
                  <span className="text-green-600">₦{selectedPlan?.price || 0}</span>
                </div>

                <Button
                  onClick={handlePurchase}
                  className="w-full bg-purple-600 hover:bg-purple-700"
                  disabled={!selectedPlan || !phoneNumber}
                >
                  <Zap className="w-4 h-4 mr-2" />
                  Buy Data Bundle
                </Button>
              </CardContent>
            </Card>

            {/* Benefits Card */}
            <Card className="bg-gradient-to-r from-purple-50 to-purple-100 border-purple-200">
              <CardContent className="p-4">
                <div className="flex items-center space-x-2 mb-2">
                  <Wifi className="w-5 h-5 text-purple-600" />
                  <span className="font-semibold text-purple-800">Why Choose Us?</span>
                </div>
                <ul className="text-sm text-purple-700 space-y-1">
                  <li>• Instant data delivery</li>
                  <li>• Best rates guaranteed</li>
                  <li>• 24/7 customer support</li>
                  <li>• PAY ID discounts available</li>
                </ul>
              </CardContent>
            </Card>
          </div>
        </div>
      </div>
    </div>
  )
}
