"use client"

import { Suspense, useState } from "react"
import { Canvas } from "@react-three/fiber"
import { Float, Text3D, OrbitControls, Environment } from "@react-three/drei"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Progress } from "@/components/ui/progress"
import {
  CreditCard,
  Phone,
  Wifi,
  Users,
  DollarSign,
  TrendingUp,
  Wallet,
  Gift,
  ArrowUpRight,
  Eye,
  EyeOff,
} from "lucide-react"
import Link from "next/link"
import { motion } from "framer-motion"

// 3D Wallet Component
function WalletScene() {
  return (
    <>
      <ambientLight intensity={0.6} />
      <pointLight position={[10, 10, 10]} />
      <Float speed={2} rotationIntensity={0.1} floatIntensity={0.2}>
        <mesh>
          <boxGeometry args={[2, 1.2, 0.1]} />
          <meshStandardMaterial color="#2563eb" />
        </mesh>
        <Text3D font="/fonts/Geist_Bold.json" size={0.2} height={0.02} position={[-0.8, 0.1, 0.06]}>
          PAY ID
          <meshStandardMaterial color="#ffffff" />
        </Text3D>
        <Text3D font="/fonts/Geist_Regular.json" size={0.15} height={0.02} position={[-0.6, -0.2, 0.06]}>
          WALLET
          <meshStandardMaterial color="#ffffff" />
        </Text3D>
      </Float>
      <OrbitControls enableZoom={false} enablePan={false} autoRotate autoRotateSpeed={2} />
      <Environment preset="sunset" />
    </>
  )
}

export default function DashboardPage() {
  const [showBalance, setShowBalance] = useState(true)
  const [tokenBalance] = useState(2450) // PAY ID tokens
  const [nairaValue] = useState(tokenBalance * 1) // 1 token = 1 naira for simplicity

  return (
    <div className="space-y-6">
      {/* Animated Welcome Section with 3D Wallet */}
      <motion.div
        initial={{ opacity: 0, y: 50 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.8 }}
        className="bg-gradient-to-r from-blue-600 to-purple-600 rounded-lg p-6 text-white relative overflow-hidden"
      >
        <div className="grid md:grid-cols-2 gap-6 items-center">
          <div>
            <motion.h1
              initial={{ x: -50 }}
              animate={{ x: 0 }}
              transition={{ duration: 0.8, delay: 0.2 }}
              className="text-2xl font-bold mb-2"
            >
              Welcome back, John!
            </motion.h1>
            <motion.p
              initial={{ x: -50 }}
              animate={{ x: 0 }}
              transition={{ duration: 0.8, delay: 0.4 }}
              className="text-blue-100 mb-4"
            >
              Ready to use your PAY ID tokens today?
            </motion.p>

            {/* Token Wallet Display */}
            <motion.div
              initial={{ scale: 0.8 }}
              animate={{ scale: 1 }}
              transition={{ duration: 0.8, delay: 0.6 }}
              className="bg-white/20 backdrop-blur-sm rounded-lg p-4"
            >
              <div className="flex items-center justify-between mb-2">
                <span className="text-sm text-blue-100">PAY ID Wallet</span>
                <Button
                  variant="ghost"
                  size="sm"
                  onClick={() => setShowBalance(!showBalance)}
                  className="text-white hover:bg-white/20"
                >
                  {showBalance ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                </Button>
              </div>
              <div className="space-y-1">
                <p className="text-2xl font-bold">
                  {showBalance ? `${tokenBalance.toLocaleString()} PAY ID` : "••••••"}
                </p>
                <p className="text-sm text-blue-100">≈ ₦{showBalance ? nairaValue.toLocaleString() : "••••••"}</p>
              </div>
            </motion.div>
          </div>

          {/* 3D Wallet */}
          <div className="h-48 relative">
            <Canvas camera={{ position: [0, 0, 4] }}>
              <Suspense fallback={null}>
                <WalletScene />
              </Suspense>
            </Canvas>
          </div>
        </div>
      </motion.div>

      {/* Animated Quick Stats */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        {[
          { icon: Wallet, label: "Total Spent", value: "15,240 PAY ID", color: "blue" },
          { icon: TrendingUp, label: "Referral Earnings", value: "3,850 PAY ID", color: "green" },
          { icon: Users, label: "Referrals", value: "12", color: "purple" },
          { icon: Gift, label: "Current Plan", value: "Premium", color: "yellow" },
        ].map((stat, index) => (
          <motion.div
            key={index}
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5, delay: index * 0.1 }}
            whileHover={{ scale: 1.05 }}
          >
            <Card>
              <CardContent className="p-4">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm text-gray-600">{stat.label}</p>
                    <p className="text-2xl font-bold">
                      {stat.label === "Current Plan" ? (
                        <Badge className="bg-yellow-100 text-yellow-800">{stat.value}</Badge>
                      ) : (
                        stat.value
                      )}
                    </p>
                  </div>
                  <motion.div whileHover={{ rotate: 360 }} transition={{ duration: 0.5 }}>
                    <stat.icon className={`w-8 h-8 text-${stat.color}-600`} />
                  </motion.div>
                </div>
              </CardContent>
            </Card>
          </motion.div>
        ))}
      </div>

      {/* Token Usage Progress */}
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.8, delay: 0.5 }}
      >
        <Card>
          <CardHeader>
            <CardTitle>Token Usage This Month</CardTitle>
            <CardDescription>Track your PAY ID token spending</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              <div className="flex justify-between text-sm">
                <span>Used: 1,250 PAY ID</span>
                <span>Remaining: 1,200 PAY ID</span>
              </div>
              <Progress value={51} className="h-2" />
              <div className="grid grid-cols-3 gap-4 text-sm">
                <div className="text-center">
                  <p className="font-semibold text-green-600">850</p>
                  <p className="text-gray-600">Airtime</p>
                </div>
                <div className="text-center">
                  <p className="font-semibold text-purple-600">300</p>
                  <p className="text-gray-600">Data</p>
                </div>
                <div className="text-center">
                  <p className="font-semibold text-blue-600">100</p>
                  <p className="text-gray-600">Other</p>
                </div>
              </div>
            </div>
          </CardContent>
        </Card>
      </motion.div>

      {/* Animated Quick Actions */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
        {[
          { href: "/airtime", icon: Phone, title: "Airtime", desc: "Buy with tokens", color: "green" },
          { href: "/data", icon: Wifi, title: "Data", desc: "Buy with tokens", color: "purple" },
          { href: "/packages", icon: CreditCard, title: "Buy Tokens", desc: "Get more PAY ID", color: "blue" },
          { href: "/earn", icon: DollarSign, title: "Earn More", desc: "Referrals", color: "yellow" },
        ].map((action, index) => (
          <motion.div
            key={index}
            initial={{ opacity: 0, scale: 0.8 }}
            animate={{ opacity: 1, scale: 1 }}
            transition={{ duration: 0.5, delay: 0.6 + index * 0.1 }}
            whileHover={{ scale: 1.05, y: -5 }}
            whileTap={{ scale: 0.95 }}
          >
            <Link href={action.href}>
              <Card className="hover:shadow-lg transition-all cursor-pointer group h-full">
                <CardContent className="p-4 text-center">
                  <motion.div whileHover={{ rotate: 360 }} transition={{ duration: 0.5 }}>
                    <action.icon className={`w-8 h-8 text-${action.color}-600 mx-auto mb-2`} />
                  </motion.div>
                  <h3 className="font-semibold">{action.title}</h3>
                  <p className="text-sm text-gray-600">{action.desc}</p>
                </CardContent>
              </Card>
            </Link>
          </motion.div>
        ))}
      </div>

      {/* Recent Transactions with Animation */}
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.8, delay: 0.8 }}
      >
        <Card>
          <CardHeader>
            <CardTitle>Recent Transactions</CardTitle>
            <CardDescription>Your latest PAY ID token activities</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              {[
                {
                  type: "Airtime",
                  amount: "-500 PAY ID",
                  network: "MTN",
                  status: "Completed",
                  time: "2 hours ago",
                  color: "red",
                },
                {
                  type: "Data",
                  amount: "-1,200 PAY ID",
                  network: "Airtel",
                  status: "Completed",
                  time: "1 day ago",
                  color: "red",
                },
                {
                  type: "Referral Bonus",
                  amount: "+100 PAY ID",
                  network: "Bonus",
                  status: "Completed",
                  time: "2 days ago",
                  color: "green",
                },
                {
                  type: "Token Purchase",
                  amount: "+5,000 PAY ID",
                  network: "Premium Package",
                  status: "Completed",
                  time: "3 days ago",
                  color: "green",
                },
              ].map((transaction, index) => (
                <motion.div
                  key={index}
                  initial={{ opacity: 0, x: -20 }}
                  animate={{ opacity: 1, x: 0 }}
                  transition={{ duration: 0.5, delay: 1 + index * 0.1 }}
                  whileHover={{ scale: 1.02 }}
                  className="flex items-center justify-between p-3 bg-gray-50 rounded-lg"
                >
                  <div className="flex items-center space-x-3">
                    <div className="w-10 h-10 bg-blue-100 rounded-full flex items-center justify-center">
                      {transaction.type === "Airtime" && <Phone className="w-5 h-5 text-blue-600" />}
                      {transaction.type === "Data" && <Wifi className="w-5 h-5 text-blue-600" />}
                      {transaction.type.includes("Token") && <CreditCard className="w-5 h-5 text-blue-600" />}
                      {transaction.type.includes("Referral") && <DollarSign className="w-5 h-5 text-blue-600" />}
                    </div>
                    <div>
                      <p className="font-medium">
                        {transaction.type} - {transaction.network}
                      </p>
                      <p className="text-sm text-gray-600">{transaction.time}</p>
                    </div>
                  </div>
                  <div className="text-right">
                    <p className={`font-semibold ${transaction.color === "green" ? "text-green-600" : "text-red-600"}`}>
                      {transaction.amount}
                    </p>
                    <Badge variant="secondary" className="text-xs">
                      {transaction.status}
                    </Badge>
                  </div>
                </motion.div>
              ))}
            </div>
            <div className="mt-4 text-center">
              <Button variant="outline">View All Transactions</Button>
            </div>
          </CardContent>
        </Card>
      </motion.div>

      {/* Animated Upgrade Prompt */}
      <motion.div
        initial={{ opacity: 0, scale: 0.9 }}
        animate={{ opacity: 1, scale: 1 }}
        transition={{ duration: 0.8, delay: 1.2 }}
        whileHover={{ scale: 1.02 }}
      >
        <Card className="bg-gradient-to-r from-yellow-50 to-orange-50 border-yellow-200">
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <h3 className="text-lg font-semibold text-yellow-800">Upgrade Your Plan</h3>
                <p className="text-yellow-700">Get better rates and higher referral commissions</p>
              </div>
              <Link href="/upgrade">
                <motion.div whileHover={{ scale: 1.05 }} whileTap={{ scale: 0.95 }}>
                  <Button className="bg-yellow-600 hover:bg-yellow-700">
                    Upgrade Now
                    <ArrowUpRight className="w-4 h-4 ml-2" />
                  </Button>
                </motion.div>
              </Link>
            </div>
          </CardContent>
        </Card>
      </motion.div>
    </div>
  )
}
