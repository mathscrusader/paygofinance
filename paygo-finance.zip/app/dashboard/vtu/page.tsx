"use client"

import { useState } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Phone, Wifi, Smartphone, Zap } from "lucide-react"
import { motion } from "framer-motion"
import Link from "next/link"

export default function VTUPage() {
  const [userTokens] = useState(2450)

  const services = [
    {
      name: "Airtime",
      icon: Phone,
      description: "Buy airtime for all networks",
      color: "bg-green-500",
      href: "/airtime",
      discount: "5% - 20%",
      networks: ["MTN", "Airtel", "Glo", "9Mobile"],
    },
    {
      name: "Data Bundles",
      icon: Wifi,
      description: "Purchase data plans",
      color: "bg-purple-500",
      href: "/data",
      discount: "10% - 25%",
      networks: ["MTN", "Airtel", "Glo", "9Mobile"],
    },
  ]

  const quickActions = [
    { name: "MTN Airtime", amount: "₦100", tokens: "95 PAY ID" },
    { name: "Airtel Data 1GB", amount: "₦280", tokens: "252 PAY ID" },
    { name: "Glo Airtime", amount: "₦200", tokens: "190 PAY ID" },
    { name: "9Mobile Data 2GB", amount: "₦520", tokens: "468 PAY ID" },
  ]

  const recentTransactions = [
    {
      type: "Airtime",
      network: "MTN",
      amount: "₦500",
      tokens: "475 PAY ID",
      status: "Completed",
      time: "2 hours ago",
    },
    {
      type: "Data",
      network: "Airtel",
      amount: "₦1,200",
      tokens: "1,080 PAY ID",
      status: "Completed",
      time: "1 day ago",
    },
    {
      type: "Airtime",
      network: "Glo",
      amount: "₦200",
      tokens: "190 PAY ID",
      status: "Completed",
      time: "2 days ago",
    },
  ]

  return (
    <div className="space-y-6">
      <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.5 }}>
        <div className="flex items-center justify-between mb-6">
          <div>
            <h1 className="text-3xl font-bold text-gray-900">VTU Services</h1>
            <p className="text-gray-600">Buy airtime and data with your PAY ID tokens</p>
          </div>
          <div className="text-right">
            <p className="text-sm text-gray-600">Your PAY ID Balance</p>
            <p className="text-2xl font-bold text-blue-600">{userTokens.toLocaleString()} PAY ID</p>
          </div>
        </div>

        {/* Service Cards */}
        <div className="grid md:grid-cols-2 gap-6 mb-8">
          {services.map((service, index) => (
            <motion.div
              key={index}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.5, delay: index * 0.1 }}
              whileHover={{ scale: 1.02, y: -5 }}
            >
              <Link href={service.href}>
                <Card className="hover:shadow-xl transition-all cursor-pointer h-full">
                  <CardHeader>
                    <div className="flex items-center space-x-3">
                      <div className={`w-12 h-12 ${service.color} rounded-lg flex items-center justify-center`}>
                        <service.icon className="w-6 h-6 text-white" />
                      </div>
                      <div>
                        <CardTitle className="text-xl">{service.name}</CardTitle>
                        <CardDescription>{service.description}</CardDescription>
                      </div>
                    </div>
                  </CardHeader>
                  <CardContent>
                    <div className="space-y-3">
                      <div className="flex items-center justify-between">
                        <span className="text-sm text-gray-600">Discount Range:</span>
                        <span className="font-semibold text-green-600">{service.discount}</span>
                      </div>
                      <div>
                        <p className="text-sm text-gray-600 mb-2">Available Networks:</p>
                        <div className="flex flex-wrap gap-1">
                          {service.networks.map((network) => (
                            <span key={network} className="px-2 py-1 bg-gray-100 text-gray-700 text-xs rounded-full">
                              {network}
                            </span>
                          ))}
                        </div>
                      </div>
                      <Button className="w-full mt-4">
                        <Zap className="w-4 h-4 mr-2" />
                        Buy {service.name}
                      </Button>
                    </div>
                  </CardContent>
                </Card>
              </Link>
            </motion.div>
          ))}
        </div>

        <Tabs defaultValue="quick" className="space-y-6">
          <TabsList className="grid w-full grid-cols-2">
            <TabsTrigger value="quick">Quick Actions</TabsTrigger>
            <TabsTrigger value="history">Transaction History</TabsTrigger>
          </TabsList>

          {/* Quick Actions */}
          <TabsContent value="quick">
            <Card>
              <CardHeader>
                <CardTitle>Quick Purchase</CardTitle>
                <CardDescription>Popular services for quick access</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="grid md:grid-cols-2 gap-4">
                  {quickActions.map((action, index) => (
                    <motion.div
                      key={index}
                      initial={{ opacity: 0, x: -20 }}
                      animate={{ opacity: 1, x: 0 }}
                      transition={{ duration: 0.5, delay: index * 0.1 }}
                      whileHover={{ scale: 1.02 }}
                      className="p-4 border rounded-lg hover:shadow-md transition-all cursor-pointer"
                    >
                      <div className="flex items-center justify-between">
                        <div>
                          <h3 className="font-semibold">{action.name}</h3>
                          <p className="text-sm text-gray-600">Amount: {action.amount}</p>
                          <p className="text-sm text-blue-600">Cost: {action.tokens}</p>
                        </div>
                        <Button size="sm">
                          <Smartphone className="w-4 h-4 mr-1" />
                          Buy
                        </Button>
                      </div>
                    </motion.div>
                  ))}
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          {/* Transaction History */}
          <TabsContent value="history">
            <Card>
              <CardHeader>
                <CardTitle>Recent VTU Transactions</CardTitle>
                <CardDescription>Your latest airtime and data purchases</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  {recentTransactions.map((transaction, index) => (
                    <motion.div
                      key={index}
                      initial={{ opacity: 0, y: 20 }}
                      animate={{ opacity: 1, y: 0 }}
                      transition={{ duration: 0.5, delay: index * 0.1 }}
                      className="flex items-center justify-between p-4 border rounded-lg"
                    >
                      <div className="flex items-center space-x-3">
                        <div className="w-10 h-10 bg-blue-100 rounded-full flex items-center justify-center">
                          {transaction.type === "Airtime" ? (
                            <Phone className="w-5 h-5 text-blue-600" />
                          ) : (
                            <Wifi className="w-5 h-5 text-blue-600" />
                          )}
                        </div>
                        <div>
                          <p className="font-semibold">
                            {transaction.network} {transaction.type}
                          </p>
                          <p className="text-sm text-gray-600">{transaction.time}</p>
                        </div>
                      </div>
                      <div className="text-right">
                        <p className="font-semibold">{transaction.amount}</p>
                        <p className="text-sm text-blue-600">{transaction.tokens}</p>
                        <span className="text-xs bg-green-100 text-green-800 px-2 py-1 rounded-full">
                          {transaction.status}
                        </span>
                      </div>
                    </motion.div>
                  ))}
                </div>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>

        {/* Benefits Card */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8, delay: 0.6 }}
        >
          <Card className="bg-gradient-to-r from-blue-50 to-purple-50 border-blue-200">
            <CardContent className="p-6">
              <div className="flex items-center space-x-2 mb-4">
                <Zap className="w-6 h-6 text-blue-600" />
                <h3 className="text-xl font-semibold text-blue-800">PAY ID Benefits</h3>
              </div>
              <div className="grid md:grid-cols-3 gap-4 text-sm">
                <div>
                  <h4 className="font-semibold text-blue-700 mb-2">Instant Processing</h4>
                  <p className="text-blue-600">All VTU transactions are processed instantly with PAY ID tokens</p>
                </div>
                <div>
                  <h4 className="font-semibold text-blue-700 mb-2">Better Rates</h4>
                  <p className="text-blue-600">Get up to 25% discount on all VTU services with higher PAY ID levels</p>
                </div>
                <div>
                  <h4 className="font-semibold text-blue-700 mb-2">24/7 Available</h4>
                  <p className="text-blue-600">Buy airtime and data anytime, anywhere with your PAY ID balance</p>
                </div>
              </div>
            </CardContent>
          </Card>
        </motion.div>
      </motion.div>
    </div>
  )
}
