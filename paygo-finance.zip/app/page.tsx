"use client"

import { useState, useEffect, useRef } from "react"
import Link from "next/link"
import { Button } from "@/components/ui/button"
import { Card, CardContent } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import {
  Bell,
  ArrowUpRight,
  Send,
  Phone,
  Wifi,
  CreditCard,
  MessageCircle,
  Users,
  DollarSign,
  User,
  Video,
  Gift,
  Star,
  Zap,
  Shield,
  Globe,
  TrendingUp,
  Award,
  CheckCircle,
  Sparkles,
  Layers,
  Rocket,
} from "lucide-react"
import { useCurrency } from "@/contexts/currency-context"
import dynamic from "next/dynamic"

// Dynamically import 3D components to avoid SSR issues
const Canvas = dynamic(() => import("@react-three/fiber").then((mod) => ({ default: mod.Canvas })), {
  ssr: false,
})
const Float = dynamic(() => import("@react-three/drei").then((mod) => ({ default: mod.Float })), {
  ssr: false,
})
const OrbitControls = dynamic(() => import("@react-three/drei").then((mod) => ({ default: mod.OrbitControls })), {
  ssr: false,
})
const Environment = dynamic(() => import("@react-three/drei").then((mod) => ({ default: mod.Environment })), {
  ssr: false,
})
const Sphere = dynamic(() => import("@react-three/drei").then((mod) => ({ default: mod.Sphere })), {
  ssr: false,
})
const Box = dynamic(() => import("@react-three/drei").then((mod) => ({ default: mod.Box })), {
  ssr: false,
})
const Torus = dynamic(() => import("@react-three/drei").then((mod) => ({ default: mod.Torus })), {
  ssr: false,
})

// Animated Icon Component
function AnimatedIcon({ icon: Icon, className = "", delay = 0 }) {
  const [isVisible, setIsVisible] = useState(false)
  const [isMounted, setIsMounted] = useState(false)
  const ref = useRef(null)

  useEffect(() => {
    setIsMounted(true)
  }, [])

  useEffect(() => {
    if (!isMounted || !ref.current) return

    const observer = new IntersectionObserver(
      ([entry]) => {
        if (entry.isIntersecting) {
          setTimeout(() => setIsVisible(true), delay)
        }
      },
      { threshold: 0.1 },
    )

    observer.observe(ref.current)

    return () => observer.disconnect()
  }, [delay, isMounted])

  if (!isMounted) {
    return (
      <div className={className}>
        <Icon className="w-full h-full" />
      </div>
    )
  }

  return (
    <div
      ref={ref}
      className={`transform transition-all duration-1000 ${
        isVisible ? "translate-y-0 opacity-100 scale-100" : "translate-y-8 opacity-0 scale-75"
      } ${className}`}
      style={{
        animation: isVisible ? `float 3s ease-in-out infinite ${delay}ms` : "none",
      }}
    >
      <Icon className="w-full h-full" />
    </div>
  )
}

// 3D Floating Elements Component
function FloatingElements() {
  const groupRef = useRef()

  // Safe frame hook that checks for ref existence
  const useFrameSafe = (callback) => {
    useEffect(() => {
      let animationId
      const animate = (state) => {
        if (groupRef.current) {
          callback(state)
        }
        animationId = requestAnimationFrame(animate)
      }
      animationId = requestAnimationFrame(animate)
      return () => cancelAnimationFrame(animationId)
    }, [callback])
  }

  return (
    <group ref={groupRef}>
      <Float speed={1.5} rotationIntensity={1} floatIntensity={2}>
        <Sphere args={[0.5, 32, 32]} position={[2, 1, 0]}>
          <meshStandardMaterial color="#8B5CF6" transparent opacity={0.7} />
        </Sphere>
      </Float>

      <Float speed={2} rotationIntensity={2} floatIntensity={1}>
        <Box args={[0.8, 0.8, 0.8]} position={[-2, -1, 1]}>
          <meshStandardMaterial color="#06B6D4" transparent opacity={0.6} />
        </Box>
      </Float>

      <Float speed={1.8} rotationIntensity={1.5} floatIntensity={1.5}>
        <Torus args={[0.6, 0.2, 16, 32]} position={[0, 2, -1]}>
          <meshStandardMaterial color="#F59E0B" transparent opacity={0.8} />
        </Torus>
      </Float>
    </group>
  )
}

export default function HomePage() {
  const { currency } = useCurrency()
  const [currentBanner, setCurrentBanner] = useState(0)
  const [currentSliders, setCurrentSliders] = useState([0, 0, 0, 0])
  const [mousePosition, setMousePosition] = useState({ x: 0, y: 0 })
  const [isMounted, setIsMounted] = useState(false)

  // Ensure component is mounted before adding event listeners
  useEffect(() => {
    setIsMounted(true)
  }, [])

  // Mouse tracking for parallax effect
  useEffect(() => {
    if (!isMounted) return

    const handleMouseMove = (e) => {
      setMousePosition({
        x: (e.clientX / window.innerWidth) * 2 - 1,
        y: (e.clientY / window.innerHeight) * 2 - 1,
      })
    }

    window.addEventListener("mousemove", handleMouseMove)
    return () => window.removeEventListener("mousemove", handleMouseMove)
  }, [isMounted])

  // Banner data for mobile
  const banners = [
    {
      title: "VTU Services",
      subtitle: "Buy airtime & data instantly",
      gradient: "from-blue-500 to-blue-700",
    },
    {
      title: "Special Offer",
      subtitle: "Get 20% bonus on first purchase",
      gradient: "from-purple-500 to-purple-700",
    },
    {
      title: "Earn Money",
      subtitle: "Refer friends and earn rewards",
      gradient: "from-green-500 to-green-700",
    },
  ]

  // Service slider data
  const serviceSliders = [
    {
      title: "Airtime Services",
      images: [
        { src: "/placeholder.svg?height=200&width=300", caption: "MTN Airtime - Fast & Reliable" },
        { src: "/placeholder.svg?height=200&width=300", caption: "Airtel Airtime - Instant Top-up" },
        { src: "/placeholder.svg?height=200&width=300", caption: "Glo Airtime - Best Rates" },
        { src: "/placeholder.svg?height=200&width=300", caption: "9mobile Airtime - Quick Service" },
      ],
    },
    {
      title: "Data Bundles",
      images: [
        { src: "/placeholder.svg?height=200&width=300", caption: "MTN Data Plans - High Speed" },
        { src: "/placeholder.svg?height=200&width=300", caption: "Airtel Data - Affordable Packages" },
        { src: "/placeholder.svg?height=200&width=300", caption: "Glo Data - Unlimited Options" },
        { src: "/placeholder.svg?height=200&width=300", caption: "9mobile Data - Best Value" },
      ],
    },
    {
      title: "PAY ID Tokens",
      images: [
        { src: "/placeholder.svg?height=200&width=300", caption: "Buy PAY ID Tokens" },
        { src: "/placeholder.svg?height=200&width=300", caption: "Earn Rewards & Bonuses" },
        { src: "/placeholder.svg?height=200&width=300", caption: "Track Your Earnings" },
        { src: "/placeholder.svg?height=200&width=300", caption: "Withdraw Anytime" },
      ],
    },
    {
      title: "Referral Program",
      images: [
        { src: "/placeholder.svg?height=200&width=300", caption: "Refer Friends & Family" },
        { src: "/placeholder.svg?height=200&width=300", caption: "Earn Commission" },
        { src: "/placeholder.svg?height=200&width=300", caption: "Track Referrals" },
        { src: "/placeholder.svg?height=200&width=300", caption: "Instant Payouts" },
      ],
    },
  ]

  // Auto-slide banners
  useEffect(() => {
    const interval = setInterval(() => {
      setCurrentBanner((prev) => (prev + 1) % banners.length)
    }, 4000)
    return () => clearInterval(interval)
  }, [banners.length])

  // Auto-slide service sliders with staggered timing
  useEffect(() => {
    const intervals = serviceSliders.map((_, index) => {
      return setInterval(
        () => {
          setCurrentSliders((prev) => {
            const newSliders = [...prev]
            newSliders[index] = (newSliders[index] + 1) % serviceSliders[index].images.length
            return newSliders
          })
        },
        3000 + index * 500,
      )
    })

    return () => intervals.forEach(clearInterval)
  }, [serviceSliders])

  const nextSlide = (sliderIndex: number) => {
    setCurrentSliders((prev) => {
      const newSliders = [...prev]
      newSliders[sliderIndex] = (newSliders[sliderIndex] + 1) % serviceSliders[sliderIndex].images.length
      return newSliders
    })
  }

  const prevSlide = (sliderIndex: number) => {
    setCurrentSliders((prev) => {
      const newSliders = [...prev]
      newSliders[sliderIndex] =
        newSliders[sliderIndex] === 0 ? serviceSliders[sliderIndex].images.length - 1 : newSliders[sliderIndex] - 1
      return newSliders
    })
  }

  if (!isMounted) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-slate-900 via-purple-900 to-slate-900 flex items-center justify-center">
        <div className="text-white text-xl">Loading...</div>
      </div>
    )
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-900 via-purple-900 to-slate-900 relative overflow-hidden">
      {/* Animated Background */}
      <div className="fixed inset-0 z-0">
        <div className="absolute inset-0 bg-gradient-to-br from-purple-900/20 via-blue-900/20 to-indigo-900/20" />
        <div
          className="absolute inset-0 opacity-30 transition-all duration-300"
          style={{
            background: `radial-gradient(circle at ${50 + mousePosition.x * 10}% ${50 + mousePosition.y * 10}%, rgba(139, 92, 246, 0.3) 0%, transparent 50%)`,
          }}
        />
        {/* Floating particles */}
        <div className="absolute inset-0">
          {[...Array(20)].map((_, i) => (
            <div
              key={i}
              className="absolute w-2 h-2 bg-white/20 rounded-full animate-pulse"
              style={{
                left: `${Math.random() * 100}%`,
                top: `${Math.random() * 100}%`,
                animationDelay: `${Math.random() * 3}s`,
                animationDuration: `${2 + Math.random() * 3}s`,
              }}
            />
          ))}
        </div>
      </div>

      {/* Mobile View */}
      <div className="md:hidden relative z-10">
        {/* Warning Banner */}
        <div className="bg-red-500/90 backdrop-blur-sm text-white p-3 text-sm border-b border-red-400/30">
          <p className="text-center animate-pulse">
            We're currently experiencing issues with Opay bank transfers. Please contact support for assistance.
          </p>
        </div>

        {/* Balance Card */}
        <div className="p-4">
          <Card className="bg-gradient-to-br from-purple-600/90 via-purple-700/90 to-indigo-800/90 text-white relative overflow-hidden backdrop-blur-lg border border-white/20 shadow-2xl">
            <div className="absolute inset-0 opacity-20">
              <div className="absolute top-4 right-4 w-20 h-20 bg-white rounded-full blur-xl animate-pulse"></div>
              <div
                className="absolute bottom-4 left-4 w-16 h-16 bg-white rounded-full blur-lg animate-pulse"
                style={{ animationDelay: "1s" }}
              ></div>
            </div>
            <CardContent className="p-6 relative">
              <div className="flex justify-between items-start mb-4">
                <div className="animate-fadeInUp">
                  <p className="text-lg font-medium">Hi, davif 👋</p>
                  <p className="text-purple-200 text-sm">Welcome back!</p>
                </div>
                <div className="animate-bounce">
                  <Bell className="h-6 w-6 text-white" />
                </div>
              </div>

              <div className="mb-6 animate-fadeInUp" style={{ animationDelay: "0.2s" }}>
                <p className="text-3xl font-bold mb-1">{currency.symbol}180,000.00</p>
                <p className="text-purple-200 text-sm">Weekly rewards: {currency.symbol}180,000.00</p>
              </div>

              <div className="flex space-x-3 animate-fadeInUp" style={{ animationDelay: "0.4s" }}>
                <Button className="bg-white/20 hover:bg-white/30 text-white border-white/30 flex-1 backdrop-blur-sm transition-all duration-300 hover:scale-105">
                  <ArrowUpRight className="h-4 w-4 mr-2" />
                  Upgrade
                </Button>
                <Button className="bg-white/20 hover:bg-white/30 text-white border-white/30 flex-1 backdrop-blur-sm transition-all duration-300 hover:scale-105">
                  <Send className="h-4 w-4 mr-2" />
                  Transfer
                </Button>
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Banner Slider */}
        <div className="px-4 mb-6">
          <div className="relative">
            <div className="overflow-hidden rounded-lg">
              <div
                className="flex transition-transform duration-500 ease-in-out"
                style={{ transform: `translateX(-${currentBanner * 100}%)` }}
              >
                {banners.map((banner, index) => (
                  <div key={index} className="w-full flex-shrink-0">
                    <div
                      className={`bg-gradient-to-r ${banner.gradient} p-6 rounded-lg text-white backdrop-blur-sm border border-white/20 shadow-lg`}
                    >
                      <h3 className="text-lg font-bold mb-2 animate-fadeInUp">{banner.title}</h3>
                      <p className="text-sm opacity-90 animate-fadeInUp" style={{ animationDelay: "0.1s" }}>
                        {banner.subtitle}
                      </p>
                    </div>
                  </div>
                ))}
              </div>
            </div>

            <div className="flex justify-center mt-3 space-x-2">
              {banners.map((_, index) => (
                <button
                  key={index}
                  className={`w-2 h-2 rounded-full transition-all duration-300 ${
                    index === currentBanner ? "bg-purple-400 scale-125" : "bg-white/40"
                  }`}
                  onClick={() => setCurrentBanner(index)}
                />
              ))}
            </div>
          </div>
        </div>

        {/* Services Grid */}
        <div className="px-4 mb-6">
          <div className="grid grid-cols-4 gap-4">
            {[
              { href: "/packages", icon: CreditCard, label: "Buy PAY ID", color: "purple", delay: 0 },
              { href: "/videos", icon: Video, label: "Video", color: "red", delay: 100 },
              { href: "/airtime", icon: Phone, label: "Airtime", color: "green", delay: 200 },
              { href: "/data", icon: Wifi, label: "Data", color: "blue", delay: 300 },
              { href: "/support", icon: MessageCircle, label: "Chat us", color: "orange", delay: 400 },
              { href: "/join-group", icon: Users, label: "Join Group", color: "indigo", delay: 500 },
              { href: "/earn", icon: DollarSign, label: "Earn More", color: "yellow", delay: 600 },
              { href: "/profile", icon: User, label: "Profile", color: "gray", delay: 700 },
            ].map((service, index) => (
              <Link key={index} href={service.href} className="group">
                <div
                  className="flex flex-col items-center p-3 bg-white/10 backdrop-blur-lg rounded-lg shadow-lg border border-white/20 transition-all duration-300 hover:scale-105 hover:bg-white/20 animate-fadeInUp"
                  style={{ animationDelay: `${service.delay}ms` }}
                >
                  <div
                    className={`w-12 h-12 bg-${service.color}-100/20 rounded-lg flex items-center justify-center mb-2 group-hover:scale-110 transition-transform duration-300`}
                  >
                    <AnimatedIcon
                      icon={service.icon}
                      className={`h-6 w-6 text-${service.color}-400`}
                      delay={service.delay}
                    />
                  </div>
                  <span className="text-xs text-center font-medium text-white">{service.label}</span>
                </div>
              </Link>
            ))}
          </div>
        </div>

        {/* Network Logos */}
        <div className="px-4 mb-6">
          <h3 className="font-semibold mb-3 text-white animate-fadeInUp">Supported Networks</h3>
          <div className="flex justify-between">
            {[
              { name: "MTN", color: "bg-yellow-400", textColor: "text-black" },
              { name: "Airtel", color: "bg-red-600", textColor: "text-white" },
              { name: "Glo", color: "bg-green-600", textColor: "text-white" },
              { name: "9mobile", color: "bg-blue-600", textColor: "text-white" },
            ].map((network, index) => (
              <div
                key={index}
                className="flex flex-col items-center animate-fadeInUp"
                style={{ animationDelay: `${index * 100}ms` }}
              >
                <div
                  className={`w-12 h-12 ${network.color} rounded-lg flex items-center justify-center mb-1 backdrop-blur-sm border border-white/20 shadow-lg transition-all duration-300 hover:scale-110 hover:rotate-3`}
                >
                  <span className={`${network.textColor} font-bold text-xs`}>{network.name}</span>
                </div>
                <span className="text-xs text-white/80">{network.name}</span>
              </div>
            ))}
          </div>
        </div>

        {/* Current Promotions */}
        <div className="px-4 mb-6">
          <Card className="bg-gradient-to-r from-purple-500/90 to-pink-500/90 text-white backdrop-blur-lg border border-white/20 shadow-2xl animate-fadeInUp">
            <CardContent className="p-4">
              <div className="flex items-center justify-between">
                <div>
                  <Badge className="bg-white/20 text-white mb-2 animate-pulse">PROMO</Badge>
                  <h3 className="font-bold">Special Offer!</h3>
                  <p className="text-sm opacity-90">Get 20% bonus on your first purchase</p>
                </div>
                <div className="animate-bounce">
                  <Gift className="h-8 w-8" />
                </div>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>

      {/* Desktop View */}
      <div className="hidden md:block relative z-10">
        {/* Hero Section with 3D Elements */}
        <section className="relative min-h-screen flex items-center justify-center overflow-hidden">
          {/* 3D Background */}
          <div className="absolute inset-0 z-0">
            <Canvas camera={{ position: [0, 0, 5], fov: 75 }}>
              <ambientLight intensity={0.5} />
              <pointLight position={[10, 10, 10]} />
              <FloatingElements />
              <Environment preset="night" />
              <OrbitControls enableZoom={false} enablePan={false} autoRotate autoRotateSpeed={0.5} />
            </Canvas>
          </div>

          <div className="relative max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-24 z-10">
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
              <div className="space-y-8">
                <div className="space-y-4">
                  <Badge className="bg-purple-500/20 text-purple-200 border-purple-400/30 backdrop-blur-sm animate-fadeInUp">
                    <Sparkles className="w-4 h-4 mr-2" />
                    New Features Available
                  </Badge>
                  <h1
                    className="text-5xl lg:text-7xl font-bold leading-tight animate-fadeInUp"
                    style={{ animationDelay: "0.2s" }}
                  >
                    Your Gateway to
                    <span className="text-transparent bg-clip-text bg-gradient-to-r from-purple-400 via-pink-400 to-cyan-400 animate-gradient">
                      {" "}
                      Digital Finance
                    </span>
                  </h1>
                  <p
                    className="text-xl text-purple-200 leading-relaxed animate-fadeInUp"
                    style={{ animationDelay: "0.4s" }}
                  >
                    Experience seamless financial services across Africa. Buy airtime, data, and manage your digital
                    wallet with cutting-edge 3D technology.
                  </p>
                </div>

                <div className="flex flex-col sm:flex-row gap-4 animate-fadeInUp" style={{ animationDelay: "0.6s" }}>
                  <Link href="/register">
                    <Button
                      size="lg"
                      className="bg-gradient-to-r from-purple-600 to-pink-600 hover:from-purple-700 hover:to-pink-700 text-white px-8 py-4 text-lg backdrop-blur-sm border border-white/20 shadow-2xl transition-all duration-300 hover:scale-105 hover:shadow-purple-500/25"
                    >
                      <Rocket className="mr-2 h-5 w-5" />
                      Get Started Free
                      <ArrowUpRight className="ml-2 h-5 w-5" />
                    </Button>
                  </Link>
                  <Link href="/dashboard">
                    <Button
                      size="lg"
                      variant="outline"
                      className="border-purple-400/50 text-purple-200 hover:bg-purple-800/50 px-8 py-4 text-lg bg-transparent backdrop-blur-sm transition-all duration-300 hover:scale-105"
                    >
                      <Layers className="mr-2 h-5 w-5" />
                      View Dashboard
                    </Button>
                  </Link>
                </div>

                <div className="flex items-center space-x-8 pt-8 animate-fadeInUp" style={{ animationDelay: "0.8s" }}>
                  {[
                    { value: "50K+", label: "Active Users" },
                    { value: "99.9%", label: "Uptime" },
                    { value: "24/7", label: "Support" },
                  ].map((stat, index) => (
                    <div key={index} className="text-center group">
                      <div className="text-2xl font-bold text-white group-hover:text-purple-300 transition-colors duration-300">
                        {stat.value}
                      </div>
                      <div className="text-purple-300 text-sm">{stat.label}</div>
                    </div>
                  ))}
                </div>
              </div>

              <div className="relative">
                {/* 3D Card Display */}
                <div className="relative z-10 animate-fadeInUp" style={{ animationDelay: "1s" }}>
                  <Card className="bg-white/10 backdrop-blur-lg border-white/20 p-6 transform rotate-3 hover:rotate-0 transition-all duration-500 shadow-2xl hover:shadow-purple-500/25">
                    <CardContent className="p-0">
                      <div className="flex items-center justify-between mb-4">
                        <div className="text-sm text-purple-200">Current Balance</div>
                        <div className="w-8 h-8 bg-gradient-to-r from-purple-500 to-pink-500 rounded-full flex items-center justify-center animate-pulse">
                          <DollarSign className="h-4 w-4 text-white" />
                        </div>
                      </div>
                      <div className="text-3xl font-bold mb-2 text-white">{currency.symbol}25,000.00</div>
                      <div className="text-purple-300 text-sm">+12% from last month</div>
                    </CardContent>
                  </Card>
                </div>

                <Card
                  className="absolute top-8 -right-4 bg-white/10 backdrop-blur-lg border-white/20 p-4 transform -rotate-3 hover:rotate-0 transition-all duration-500 shadow-2xl animate-fadeInUp"
                  style={{ animationDelay: "1.2s" }}
                >
                  <CardContent className="p-0">
                    <div className="flex items-center space-x-3">
                      <div className="w-10 h-10 bg-gradient-to-r from-green-500 to-emerald-500 rounded-full flex items-center justify-center animate-bounce">
                        <CheckCircle className="h-5 w-5 text-white" />
                      </div>
                      <div>
                        <div className="font-semibold text-white">Transaction Complete</div>
                        <div className="text-purple-300 text-sm">Airtime purchase successful</div>
                      </div>
                    </div>
                  </CardContent>
                </Card>

                {/* Simple 3D Element without Canvas */}
                <div
                  className="absolute -top-10 -left-10 w-20 h-20 bg-gradient-to-r from-purple-500 to-pink-500 rounded-full animate-pulse opacity-60 animate-fadeInUp"
                  style={{ animationDelay: "1.4s" }}
                ></div>
              </div>
            </div>
          </div>
        </section>

        {/* Features Grid with 3D Icons */}
        <section className="py-16 bg-black/20 backdrop-blur-sm border-y border-white/10">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div className="text-center mb-12">
              <h2 className="text-3xl font-bold text-white mb-4 animate-fadeInUp">Everything You Need</h2>
              <p className="text-xl text-purple-200 animate-fadeInUp" style={{ animationDelay: "0.2s" }}>
                Comprehensive digital financial services at your fingertips
              </p>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
              {[
                {
                  icon: Phone,
                  title: "Airtime Top-up",
                  desc: "Instant airtime for all networks across Africa",
                  color: "purple",
                  delay: 0,
                },
                {
                  icon: Wifi,
                  title: "Data Bundles",
                  desc: "Affordable data plans for all your needs",
                  color: "blue",
                  delay: 200,
                },
                {
                  icon: CreditCard,
                  title: "PAY ID Tokens",
                  desc: "Earn rewards with our token system",
                  color: "green",
                  delay: 400,
                },
                {
                  icon: DollarSign,
                  title: "Earn More",
                  desc: "Multiple ways to earn and grow your income",
                  color: "yellow",
                  delay: 600,
                },
              ].map((feature, index) => (
                <Card
                  key={index}
                  className="p-6 bg-white/5 backdrop-blur-lg border border-white/10 hover:bg-white/10 transition-all duration-500 hover:scale-105 hover:shadow-2xl group animate-fadeInUp"
                  style={{ animationDelay: `${feature.delay}ms` }}
                >
                  <CardContent className="p-0 text-center">
                    <div
                      className={`w-16 h-16 bg-${feature.color}-500/20 rounded-full flex items-center justify-center mx-auto mb-4 group-hover:scale-110 transition-transform duration-300`}
                    >
                      <AnimatedIcon
                        icon={feature.icon}
                        className={`h-8 w-8 text-${feature.color}-400`}
                        delay={feature.delay}
                      />
                    </div>
                    <h3 className="text-lg font-semibold mb-2 text-white">{feature.title}</h3>
                    <p className="text-purple-200 text-sm">{feature.desc}</p>
                  </CardContent>
                </Card>
              ))}
            </div>
          </div>
        </section>

        {/* Benefits Section with Animated Stats */}
        <section className="py-16 bg-gradient-to-r from-purple-900/50 to-indigo-900/50 backdrop-blur-sm">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
              <div className="space-y-8">
                <div className="animate-fadeInUp">
                  <h2 className="text-3xl font-bold text-white mb-4">Why Choose PayGo Finance?</h2>
                  <p className="text-xl text-purple-200">
                    Experience the future of digital finance with our cutting-edge 3D platform
                  </p>
                </div>

                <div className="space-y-6">
                  {[
                    {
                      icon: Zap,
                      title: "Lightning Fast",
                      desc: "Instant transactions and real-time processing for all your financial needs",
                      color: "purple",
                    },
                    {
                      icon: Shield,
                      title: "Bank-Level Security",
                      desc: "Your data and transactions are protected with enterprise-grade security",
                      color: "green",
                    },
                    {
                      icon: Globe,
                      title: "Pan-African Coverage",
                      desc: "Available across multiple African countries with local support",
                      color: "blue",
                    },
                    {
                      icon: Award,
                      title: "Reward System",
                      desc: "Earn points and bonuses with every transaction you make",
                      color: "yellow",
                    },
                  ].map((benefit, index) => (
                    <div
                      key={index}
                      className="flex items-start space-x-4 animate-fadeInUp"
                      style={{ animationDelay: `${index * 200}ms` }}
                    >
                      <div
                        className={`w-12 h-12 bg-${benefit.color}-500/20 rounded-lg flex items-center justify-center flex-shrink-0 backdrop-blur-sm border border-white/10`}
                      >
                        <AnimatedIcon
                          icon={benefit.icon}
                          className={`h-6 w-6 text-${benefit.color}-400`}
                          delay={index * 200}
                        />
                      </div>
                      <div>
                        <h3 className="text-lg font-semibold mb-2 text-white">{benefit.title}</h3>
                        <p className="text-purple-200">{benefit.desc}</p>
                      </div>
                    </div>
                  ))}
                </div>
              </div>

              <div className="relative">
                <div className="grid grid-cols-2 gap-4">
                  {[
                    { icon: TrendingUp, value: "150%", label: "Growth Rate", color: "purple" },
                    { icon: Users, value: "50K+", label: "Happy Users", color: "green" },
                    { icon: Star, value: "4.9", label: "Rating", color: "blue" },
                    { icon: CheckCircle, value: "99.9%", label: "Uptime", color: "yellow" },
                  ].map((stat, index) => (
                    <Card
                      key={index}
                      className={`p-4 bg-gradient-to-br from-${stat.color}-500/20 to-${stat.color}-600/20 backdrop-blur-lg border border-white/10 hover:scale-105 transition-all duration-300 animate-fadeInUp`}
                      style={{ animationDelay: `${index * 150}ms` }}
                    >
                      <CardContent className="p-0 text-center">
                        <AnimatedIcon
                          icon={stat.icon}
                          className={`h-8 w-8 text-${stat.color}-400 mx-auto mb-2`}
                          delay={index * 150}
                        />
                        <div className={`text-2xl font-bold text-${stat.color}-300`}>{stat.value}</div>
                        <div className={`text-${stat.color}-400 text-sm`}>{stat.label}</div>
                      </CardContent>
                    </Card>
                  ))}
                </div>
              </div>
            </div>
          </div>
        </section>

        {/* CTA Section */}
        <section className="py-16 bg-gradient-to-r from-purple-600/80 to-indigo-600/80 text-white backdrop-blur-lg border-t border-white/10">
          <div className="max-w-4xl mx-auto text-center px-4 sm:px-6 lg:px-8">
            <h2 className="text-3xl font-bold mb-4 animate-fadeInUp">Ready to Get Started?</h2>
            <p className="text-xl text-purple-200 mb-8 animate-fadeInUp" style={{ animationDelay: "0.2s" }}>
              Join thousands of users who trust PayGo Finance for their digital financial needs
            </p>
            <div
              className="flex flex-col sm:flex-row gap-4 justify-center animate-fadeInUp"
              style={{ animationDelay: "0.4s" }}
            >
              <Link href="/register">
                <Button
                  size="lg"
                  className="bg-white text-purple-600 hover:bg-gray-100 px-8 py-4 text-lg transition-all duration-300 hover:scale-105 shadow-2xl"
                >
                  Create Free Account
                  <ArrowUpRight className="ml-2 h-5 w-5" />
                </Button>
              </Link>
              <Link href="/packages">
                <Button
                  size="lg"
                  variant="outline"
                  className="border-white text-white hover:bg-white/10 px-8 py-4 text-lg bg-transparent backdrop-blur-sm transition-all duration-300 hover:scale-105"
                >
                  View Packages
                </Button>
              </Link>
            </div>
          </div>
        </section>
      </div>

      <style jsx>{`
        @keyframes float {
          0%, 100% { transform: translateY(0px); }
          50% { transform: translateY(-10px); }
        }
        
        @keyframes fadeInUp {
          from {
            opacity: 0;
            transform: translateY(30px);
          }
          to {
            opacity: 1;
            transform: translateY(0);
          }
        }
        
        @keyframes gradient {
          0%, 100% { background-position: 0% 50%; }
          50% { background-position: 100% 50%; }
        }
        
        .animate-fadeInUp {
          animation: fadeInUp 0.8s ease-out forwards;
        }
        
        .animate-gradient {
          background-size: 200% 200%;
          animation: gradient 3s ease infinite;
        }
      `}</style>
    </div>
  )
}
